import { describe, it, expect, vi, beforeEach } from 'vitest'

/**
 * La capa application/ de `content` (createContent.ts, updateContent.ts, etc.)
 * es deliberadamente fina: valida con zod (`.parse`, que lanza en vez de
 * devolver un resultado) y delega en el repositorio concreto — a diferencia
 * de `modules/feed/application/`, aquí NO se inyecta el repositorio como
 * parámetro, sino que se importa el singleton `supabaseXxxRepository`
 * directamente (ver PROGRESO.md / informe de auditoría). Eso hace que la
 * única forma de testear esta capa sin levantar Supabase sea mockear el
 * módulo de infraestructura con vi.mock — lo que este fichero hace, uno
 * por cada función de application/.
 *
 * Lo que se prueba en cada caso es el contrato real: con datos válidos, se
 * llama al repositorio con los datos ya parseados/normalizados por zod; con
 * datos inválidos, el repositorio NUNCA se llega a tocar.
 */

const CONTENT_ID = '3c9a5b8e-6f2a-4b1a-9b1a-2f6a5c9d1e3f'

vi.mock('@/modules/content/infrastructure/supabaseContentRepository', () => ({
  supabaseContentRepository: {
    list: vi.fn(),
    getById: vi.fn(),
    createDraft: vi.fn(),
    update: vi.fn(),
    delete: vi.fn(),
    publish: vi.fn(),
    schedule: vi.fn(),
    unpublish: vi.fn(),
  },
}))

vi.mock(
  '@/modules/content/infrastructure/supabaseCaseDetailRepository',
  () => ({
    supabaseCaseDetailRepository: {
      getByContentId: vi.fn(),
      upsert: vi.fn(),
    },
  }),
)

vi.mock(
  '@/modules/content/infrastructure/supabaseContentTranslationRepository',
  () => ({
    supabaseContentTranslationRepository: {
      listByContentId: vi.fn(),
      upsert: vi.fn(),
    },
  }),
)

beforeEach(() => {
  vi.clearAllMocks()
})

describe('createContent', () => {
  it('valida con zod y delega en supabaseContentRepository.createDraft con los datos recortados', async () => {
    const { createContent } =
      await import('@/modules/content/application/createContent')
    const { supabaseContentRepository } =
      await import('@/modules/content/infrastructure/supabaseContentRepository')

    vi.mocked(supabaseContentRepository.createDraft).mockResolvedValue(
      CONTENT_ID,
    )

    const result = await createContent({
      type: 'case',
      slug: '  mi-caso  ',
      defaultLocale: 'es',
      title: '  Mi caso  ',
    })

    expect(result).toBe(CONTENT_ID)
    expect(supabaseContentRepository.createDraft).toHaveBeenCalledWith({
      type: 'case',
      slug: 'mi-caso',
      defaultLocale: 'es',
      title: 'Mi caso',
    })
  })

  it('rechaza un slug inválido sin llegar a llamar al repositorio', async () => {
    const { createContent } =
      await import('@/modules/content/application/createContent')
    const { supabaseContentRepository } =
      await import('@/modules/content/infrastructure/supabaseContentRepository')

    await expect(
      createContent({
        type: 'case',
        slug: 'Slug Inválido',
        defaultLocale: 'es',
        title: 'Mi caso',
      }),
    ).rejects.toThrow()

    expect(supabaseContentRepository.createDraft).not.toHaveBeenCalled()
  })
})

describe('updateContent', () => {
  it('delega en supabaseContentRepository.update sin permitir cambiar el tipo', async () => {
    const { updateContent } =
      await import('@/modules/content/application/updateContent')
    const { supabaseContentRepository } =
      await import('@/modules/content/infrastructure/supabaseContentRepository')

    vi.mocked(supabaseContentRepository.update).mockResolvedValue(CONTENT_ID)

    await updateContent({
      id: CONTENT_ID,
      slug: 'nuevo-slug',
      defaultLocale: 'en',
    })

    expect(supabaseContentRepository.update).toHaveBeenCalledWith({
      id: CONTENT_ID,
      slug: 'nuevo-slug',
      defaultLocale: 'en',
    })
  })

  it('rechaza un id que no sea uuid sin llamar al repositorio', async () => {
    const { updateContent } =
      await import('@/modules/content/application/updateContent')
    const { supabaseContentRepository } =
      await import('@/modules/content/infrastructure/supabaseContentRepository')

    await expect(
      updateContent({ id: 'no-es-uuid', slug: 'slug', defaultLocale: 'es' }),
    ).rejects.toThrow()

    expect(supabaseContentRepository.update).not.toHaveBeenCalled()
  })
})

describe('deleteContent', () => {
  it('delega en supabaseContentRepository.delete con un id válido', async () => {
    const { deleteContent } =
      await import('@/modules/content/application/deleteContent')
    const { supabaseContentRepository } =
      await import('@/modules/content/infrastructure/supabaseContentRepository')

    vi.mocked(supabaseContentRepository.delete).mockResolvedValue(CONTENT_ID)

    const result = await deleteContent({ id: CONTENT_ID })

    expect(result).toBe(CONTENT_ID)
    expect(supabaseContentRepository.delete).toHaveBeenCalledWith({
      id: CONTENT_ID,
    })
  })

  it("rechaza un id vacío sin llamar al repositorio — la restricción 'solo draft' la impone la función SQL, no esta capa", async () => {
    const { deleteContent } =
      await import('@/modules/content/application/deleteContent')
    const { supabaseContentRepository } =
      await import('@/modules/content/infrastructure/supabaseContentRepository')

    await expect(deleteContent({ id: '' })).rejects.toThrow()
    expect(supabaseContentRepository.delete).not.toHaveBeenCalled()
  })
})

describe('upsertCaseDetail', () => {
  it('delega en supabaseCaseDetailRepository.upsert con force dentro de rango — solo force + client (especificacion-final-formato-detalle.md §3, §6)', async () => {
    const { upsertCaseDetail } =
      await import('@/modules/content/application/upsertCaseDetail')
    const { supabaseCaseDetailRepository } =
      await import('@/modules/content/infrastructure/supabaseCaseDetailRepository')

    vi.mocked(supabaseCaseDetailRepository.upsert).mockResolvedValue(CONTENT_ID)

    await upsertCaseDetail({
      contentId: CONTENT_ID,
      force: 3,
      client: null,
    })

    expect(supabaseCaseDetailRepository.upsert).toHaveBeenCalledOnce()
  })

  it('rechaza force fuera de 1-5 sin llamar al repositorio', async () => {
    const { upsertCaseDetail } =
      await import('@/modules/content/application/upsertCaseDetail')
    const { supabaseCaseDetailRepository } =
      await import('@/modules/content/infrastructure/supabaseCaseDetailRepository')

    await expect(
      upsertCaseDetail({
        contentId: CONTENT_ID,
        force: 7,
        client: null,
      }),
    ).rejects.toThrow()

    expect(supabaseCaseDetailRepository.upsert).not.toHaveBeenCalled()
  })
})

describe('upsertContentTranslation', () => {
  it('rechaza un título vacío sin llamar al repositorio', async () => {
    const { upsertContentTranslation } =
      await import('@/modules/content/application/upsertContentTranslation')
    const { supabaseContentTranslationRepository } =
      await import('@/modules/content/infrastructure/supabaseContentTranslationRepository')

    await expect(
      upsertContentTranslation({
        contentId: CONTENT_ID,
        locale: 'es',
        title: '',
        seoTitle: null,
        seoDescription: null,
        summary: null,
        highlight: null,
        body: null,
      }),
    ).rejects.toThrow()

    expect(supabaseContentTranslationRepository.upsert).not.toHaveBeenCalled()
  })

  it('acepta highlight/body explícitos (§3: campos propios del formato tipo B) y delega en el repositorio', async () => {
    const { upsertContentTranslation } =
      await import('@/modules/content/application/upsertContentTranslation')
    const { supabaseContentTranslationRepository } =
      await import('@/modules/content/infrastructure/supabaseContentTranslationRepository')

    vi.mocked(supabaseContentTranslationRepository.upsert).mockResolvedValue(
      CONTENT_ID,
    )

    await upsertContentTranslation({
      contentId: CONTENT_ID,
      locale: 'es',
      title: 'Título',
      seoTitle: null,
      seoDescription: null,
      summary: null,
      highlight: 'Subtítulo',
      body: 'Cuerpo del caso',
    })

    expect(supabaseContentTranslationRepository.upsert).toHaveBeenCalledOnce()
  })
})

describe('publishContent', () => {
  it('delega en supabaseContentRepository.publish', async () => {
    const { publishContent } =
      await import('@/modules/content/application/publishContent')
    const { supabaseContentRepository } =
      await import('@/modules/content/infrastructure/supabaseContentRepository')

    vi.mocked(supabaseContentRepository.publish).mockResolvedValue(CONTENT_ID)

    const result = await publishContent({ id: CONTENT_ID })

    expect(result).toBe(CONTENT_ID)
    expect(supabaseContentRepository.publish).toHaveBeenCalledWith({
      id: CONTENT_ID,
    })
  })

  it('rechaza un id inválido sin llamar al repositorio', async () => {
    const { publishContent } =
      await import('@/modules/content/application/publishContent')
    const { supabaseContentRepository } =
      await import('@/modules/content/infrastructure/supabaseContentRepository')

    await expect(publishContent({ id: 'no-es-uuid' })).rejects.toThrow()

    expect(supabaseContentRepository.publish).not.toHaveBeenCalled()
  })
})

describe('scheduleContent', () => {
  it('delega en supabaseContentRepository.schedule con una fecha futura', async () => {
    const { scheduleContent } =
      await import('@/modules/content/application/scheduleContent')
    const { supabaseContentRepository } =
      await import('@/modules/content/infrastructure/supabaseContentRepository')

    vi.mocked(supabaseContentRepository.schedule).mockResolvedValue(CONTENT_ID)

    const future = new Date(Date.now() + 60_000)

    const result = await scheduleContent({ id: CONTENT_ID, publishAt: future })

    expect(result).toBe(CONTENT_ID)
    expect(supabaseContentRepository.schedule).toHaveBeenCalledOnce()

    const calledWith = vi.mocked(supabaseContentRepository.schedule).mock
      .calls[0][0]
    expect(calledWith.id).toBe(CONTENT_ID)
    expect(calledWith.publishAt).toBeInstanceOf(Date)
  })

  it('rechaza una fecha pasada sin llamar al repositorio', async () => {
    const { scheduleContent } =
      await import('@/modules/content/application/scheduleContent')
    const { supabaseContentRepository } =
      await import('@/modules/content/infrastructure/supabaseContentRepository')

    const past = new Date(Date.now() - 60_000)

    await expect(
      scheduleContent({ id: CONTENT_ID, publishAt: past }),
    ).rejects.toThrow()

    expect(supabaseContentRepository.schedule).not.toHaveBeenCalled()
  })
})

describe('unpublishContent', () => {
  it('delega en supabaseContentRepository.unpublish', async () => {
    const { unpublishContent } =
      await import('@/modules/content/application/unpublishContent')
    const { supabaseContentRepository } =
      await import('@/modules/content/infrastructure/supabaseContentRepository')

    vi.mocked(supabaseContentRepository.unpublish).mockResolvedValue(CONTENT_ID)

    const result = await unpublishContent({ id: CONTENT_ID })

    expect(result).toBe(CONTENT_ID)
    expect(supabaseContentRepository.unpublish).toHaveBeenCalledWith({
      id: CONTENT_ID,
    })
  })

  it('rechaza un id inválido sin llamar al repositorio', async () => {
    const { unpublishContent } =
      await import('@/modules/content/application/unpublishContent')
    const { supabaseContentRepository } =
      await import('@/modules/content/infrastructure/supabaseContentRepository')

    await expect(unpublishContent({ id: 'no-es-uuid' })).rejects.toThrow()

    expect(supabaseContentRepository.unpublish).not.toHaveBeenCalled()
  })
})
