import {
  pinRatioSchema,
  RATIO_DECIMAL_VALUE,
  type PinRatioValue,
} from '@/modules/shared/domain/ratio'

/**
 * Sugerencia automática del campo `ratio` de una portada
 * (especificacion-final-formato-detalle.md §2, §4) a partir de las
 * dimensiones reales del archivo que se acaba de elegir en el ABM — el
 * admin sigue pudiendo cambiarla a mano antes de subir, esto solo
 * precarga el `<select>` con la opción más parecida, nunca decide por su
 * cuenta ni se guarda en servidor sin que el admin lo confirme.
 *
 * Comparar por diferencia absoluta de ancho/alto sesga hacia los ratios
 * "grandes" (1,78 de 16:9 absorbe más rango que 0,5625 de 9:16 aunque
 * ambos representen el mismo "grado de apaisado/vertical" en sentidos
 * opuestos) porque los ratios no son una escala lineal, son una relación
 * multiplicativa. Comparar en escala logarítmica corrige ese sesgo: la
 * distancia entre 16:9 y 1:1 en log-espacio es la misma que entre 1:1 y
 * 9:16, aunque en valor absoluto 16:9-1:1 (0,78) y 1:1-9:16 (0,44) no se
 * parezcan nada.
 */

export function closestClosedRatio(
  width: number,
  height: number,
): PinRatioValue {
  if (!Number.isFinite(width) || !Number.isFinite(height) || height <= 0) {
    throw new Error(
      `Dimensiones inválidas para sugerir ratio: width=${width}, height=${height}`,
    )
  }

  const actualRatio = width / height
  const logActual = Math.log(actualRatio)

  let closest: PinRatioValue = pinRatioSchema.options[0]
  let closestDistance = Infinity

  for (const candidate of pinRatioSchema.options) {
    const distance = Math.abs(
      logActual - Math.log(RATIO_DECIMAL_VALUE[candidate]),
    )
    if (distance < closestDistance) {
      closestDistance = distance
      closest = candidate
    }
  }

  return closest
}

/**
 * ¿Las dimensiones reales de un medio encajan con el ratio cerrado de un
 * pin? Se compara en escala logarítmica (misma razón que en
 * closestClosedRatio) con una tolerancia del 5 %: 1920×1080 encaja con
 * 16:9, 1080×1350 con 4:5, y 1440×900 (16:10) no encaja con ninguno. Lo usa
 * el ABM para AVISAR (nunca bloquear) de que el vídeo se va a recortar con
 * `object-fit: cover` si su ratio real no es el del pin.
 */
const RATIO_MATCH_TOLERANCE = 0.05

/** ¿Es este texto uno de los 7 ratios cerrados de pin? */
export function isPinRatioValue(value: string): value is PinRatioValue {
  return value in RATIO_DECIMAL_VALUE
}

export function mediaMatchesRatio(
  width: number,
  height: number,
  ratio: PinRatioValue,
): boolean {
  if (!Number.isFinite(width) || !Number.isFinite(height) || height <= 0) {
    return false
  }

  const distance = Math.abs(
    Math.log(width / height) - Math.log(RATIO_DECIMAL_VALUE[ratio]),
  )

  return distance <= RATIO_MATCH_TOLERANCE
}

/**
 * Ratio fijo de todo el carrusel de detalle de un caso (tipo B —
 * especificacion-final-formato-detalle.md §1, §3): se usa el ratio de la imagen/vídeo MÁS ANCHO del
 * carrusel (el de mayor width/height) para todas las diapositivas por
 * igual, y el resto se encaja dentro de esa ventana con barras negras
 * (`object-fit: contain`) en vez de recortarlas.
 *
 * Deliberadamente NO se recalcula por diapositiva: el ratio se calcula
 * UNA VEZ a partir de todos los medios del carrusel (server-side, antes
 * de renderizar) y se queda fijo mientras se navega entre slides — mover
 * la caja de texto en cada cambio de slide porque cada imagen tiene un
 * ratio distinto no tiene sentido visual.
 */
export function widestCarouselRatio(
  media: { width: number; height: number }[],
): PinRatioValue {
  if (media.length === 0) {
    throw new Error(
      'widestCarouselRatio necesita al menos un medio — un carrusel de caso siempre trae 1-N (especificacion-final-formato-detalle.md §3).',
    )
  }

  let widest = media[0]
  let widestActualRatio = widest.width / widest.height

  for (const item of media.slice(1)) {
    const actualRatio = item.width / item.height
    if (actualRatio > widestActualRatio) {
      widest = item
      widestActualRatio = actualRatio
    }
  }

  return closestClosedRatio(widest.width, widest.height)
}
