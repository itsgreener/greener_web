import type { AppSupabaseClient } from '@/lib/supabase/database'
import { createServiceClient } from '@/lib/supabase/serviceClient'

import type {
  FeedSession,
  FeedSessionRepository,
  NewFeedSession,
} from '@/modules/feed/domain/feedPorts'
import { parseFeedScope } from '@/modules/feed/domain/feedScope'

/**
 * Persistencia de feed_session/feed_round (arquitectura §8.5). Usa
 * siempre la service role key (serviceClient.ts) porque estas dos tablas
 * no tienen política pública — es deliberado, no un descuido de RLS (ver
 * comentario en supabase/migrations/20260806090700_rls_policies.sql).
 */

async function createFeedSessionRow(
  params: NewFeedSession,
  client: AppSupabaseClient = createServiceClient(),
): Promise<FeedSession> {
  // Seed criptográficamente aleatoria por carga de documento (arquitectura
  // §6.1) — no derivada de nada predecible por el cliente.
  const seed = crypto.randomUUID()

  const { data, error } = await client
    .from('feed_session')
    .insert({
      seed,
      scope: params.scope,
      filter_hash: params.filterHash,
      exclude_content_id: params.excludeContentId ?? null,
    })
    .select('id, seed, scope, expires_at, exclude_content_id')
    .single()

  if (error || !data) {
    throw new Error(
      `No se pudo crear la sesión de feed: ${error?.message ?? 'sin datos'}`,
    )
  }

  return {
    id: data.id,
    seed: data.seed,
    scope: parseFeedScope(data.scope),
    expiresAt: data.expires_at,
    excludeContentId: data.exclude_content_id,
  }
}

async function getFeedSessionRow(
  sessionId: string,
  client: AppSupabaseClient = createServiceClient(),
): Promise<FeedSession | null> {
  const { data, error } = await client
    .from('feed_session')
    .select('id, seed, scope, expires_at, exclude_content_id')
    .eq('id', sessionId)
    .maybeSingle()

  if (error) {
    throw new Error(`No se pudo leer la sesión de feed: ${error.message}`)
  }
  if (!data) return null

  return {
    id: data.id,
    seed: data.seed,
    scope: parseFeedScope(data.scope),
    expiresAt: data.expires_at,
    excludeContentId: data.exclude_content_id,
  }
}

async function getFeedRound(
  sessionId: string,
  roundIndex: number,
  client: AppSupabaseClient = createServiceClient(),
): Promise<string[] | null> {
  const { data, error } = await client
    .from('feed_round')
    .select('ordered_pin_ids')
    .eq('session_id', sessionId)
    .eq('round_index', roundIndex)
    .maybeSingle()

  if (error) {
    throw new Error(`No se pudo leer la ronda del feed: ${error.message}`)
  }
  return data?.ordered_pin_ids ?? null
}

/**
 * Persiste una ronda ya calculada. Una vez guardada, es inmutable: los
 * pines ya servidos no se modifican aunque cambie el contenido publicado
 * después (arquitectura §8.5). `upsert` con ese conflicto es solo defensa
 * ante una carrera entre dos requests concurrentes pidiendo la misma
 * ronda por primera vez a la vez — el resultado, al ser determinista para
 * la misma seed+ronda, sería idéntico igualmente.
 */
async function saveFeedRound(
  sessionId: string,
  roundIndex: number,
  orderedPinIds: string[],
  client: AppSupabaseClient = createServiceClient(),
): Promise<void> {
  const { error } = await client.from('feed_round').upsert(
    {
      session_id: sessionId,
      round_index: roundIndex,
      ordered_pin_ids: orderedPinIds,
    },
    { onConflict: 'session_id,round_index' },
  )

  if (error) {
    throw new Error(`No se pudo guardar la ronda del feed: ${error.message}`)
  }
}

export const supabaseFeedSessionRepository: FeedSessionRepository = {
  create: (params) => createFeedSessionRow(params),
  get: (sessionId) => getFeedSessionRow(sessionId),
  getRound: (sessionId, roundIndex) => getFeedRound(sessionId, roundIndex),
  saveRound: (sessionId, roundIndex, orderedPinIds) =>
    saveFeedRound(sessionId, roundIndex, orderedPinIds),
}
