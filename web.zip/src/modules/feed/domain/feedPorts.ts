import type {
  FeedDataset,
  FeedInterlude,
  PinDirectoryEntry,
} from './feedReadModels'
import type { FeedScope } from './feedScope'
import type { FeedConfig } from './types'

export interface FeedSession {
  id: string
  seed: string
  scope: FeedScope
  expiresAt: string
  /**
   * Contenido a excluir del universo de esta sesión (panel de
   * recomendaciones de una página de detalle — no debe recomendarse a sí
   * misma). `null` en toda sesión de home/subhome normal.
   */
  excludeContentId: string | null
}

export interface NewFeedSession {
  scope: FeedScope
  filterHash: string | null
  excludeContentId?: string | null
}

/** Persistencia de feed_session/feed_round (arquitectura §8.5). */
export interface FeedSessionRepository {
  create(params: NewFeedSession): Promise<FeedSession>

  get(sessionId: string): Promise<FeedSession | null>

  getRound(sessionId: string, roundIndex: number): Promise<string[] | null>

  /** Una ronda guardada es inmutable (arquitectura §8.5). */
  saveRound(
    sessionId: string,
    roundIndex: number,
    orderedPinIds: string[],
  ): Promise<void>
}

/** Lo publicado, visto desde el feed. */
export interface FeedCatalog {
  /** Universo completo del scope, para generar una ronda nueva. */
  dataset(
    scope: FeedScope,
    excludeContentId?: string | null,
  ): Promise<FeedDataset>

  /** Fichas de unas unidades ya decididas, sin releer el catálogo entero. */
  directoryByIds(unitIds: string[]): Promise<Record<string, PinDirectoryEntry>>

  config(): Promise<FeedConfig>

  /**
   * Contenidos `other` publicados y servibles, con su frecuencia. No forman
   * parte del universo de la ronda: el calendario de interludios
   * (`domain/interludes.ts`) los intercala al servir cada lote.
   */
  interludes(): Promise<FeedInterlude[]>
}

export interface FeedCursorPayload {
  sessionId: string
  roundIndex: number
  // Posición dentro de la ronda (pines ya servidos de ella). 0 = principio.
  offset: number
  // Pines de ronda servidos en TODA la sesión (sin contar los interludios):
  // es el contador sobre el que se calcula el calendario de interludios. Un
  // cursor anterior a este campo se lee como 0.
  served: number
}

/** Cursor opaco y firmado: el cliente no puede alterar cuotas ni seed. */
export interface FeedCursorCodec {
  encode(payload: FeedCursorPayload): string

  /** null si es inválido, ajeno o está corrupto. */
  decode(cursor: string): FeedCursorPayload | null
}

/**
 * Límites de peticiones del feed público, por visitante (cookie anónima) y por
 * IP: la cookie la controla quien hace la petición y rotarla es gratis, la IP
 * no tanto. Son asíncronos porque el contador puede vivir en un almacén
 * compartido entre instancias (SEC-PUB-A1).
 */
export interface FeedRequestLimits {
  canCreateSession(visitorId: string, ip?: string | null): Promise<boolean>

  canFetchBatch(visitorId: string, ip?: string | null): Promise<boolean>

  rememberSession(
    visitorId: string,
    sessionId: string,
    scope: FeedScope,
  ): Promise<void>

  getLastSession(visitorId: string, scope: FeedScope): Promise<string | null>
}
