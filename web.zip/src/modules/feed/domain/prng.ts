import { fnv1a32 } from '@/modules/shared/domain/hash'

/**
 * PRNG determinista (mulberry32): misma seed numérica siempre produce la
 * misma secuencia de floats en [0, 1). Rápido, sin dependencias, suficiente
 * para un algoritmo de mezcla no criptográfico (arquitectura §8, ADR-02.4).
 */
export type Rng = () => number

export function mulberry32(seed: number): Rng {
  let a = seed >>> 0
  return function rng() {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

/**
 * Hash determinista de una cadena a un entero de 32 bits (FNV-1a).
 * Permite derivar una seed numérica reproducible a partir de la seed de
 * sesión (string) combinada con una clave (id de caso, tipo de pool, ronda...).
 */
export function hashToSeed(...parts: (string | number)[]): number {
  return fnv1a32(parts.join('::'))
}

/** Crea un Rng determinista a partir de la seed de sesión + una clave de contexto. */
export function deriveRng(seed: string, ...key: (string | number)[]): Rng {
  return mulberry32(hashToSeed(seed, ...key))
}

/** Entero aleatorio determinista en [0, max). */
export function randomInt(rng: Rng, max: number): number {
  if (max <= 0) return 0
  return Math.floor(rng() * max)
}

/**
 * Copia de `items` en un orden aleatorio determinista (Fisher-Yates con el
 * Rng dado). No muta la entrada. Para que dos llamadas con la misma seed den
 * el mismo orden, la lista de entrada debe llegar ya en un orden canónico:
 * el orden en que Supabase devuelve las filas no está garantizado.
 */
export function shuffled<T>(items: readonly T[], rng: Rng): T[] {
  const out = [...items]
  for (let i = out.length - 1; i > 0; i--) {
    const j = randomInt(rng, i + 1)
    ;[out[i], out[j]] = [out[j], out[i]]
  }
  return out
}
