import { createClient } from '@/lib/supabase/server'

import type { CaseDetailRepository } from '@/modules/content/domain/caseDetailRepository'

import type {
  CaseDetail,
  UpsertCaseDetailInput,
} from '@/modules/content/domain/caseDetailSchema'
import { createRepositoryError } from '@/lib/supabase/repositoryError'

type SupabaseCaseDetailRow = {
  content_id: string
  force: number
  client: string | null
}

function mapCaseDetail(row: SupabaseCaseDetailRow): CaseDetail {
  return {
    contentId: row.content_id,

    force: row.force,

    client: row.client,
  }
}

export const supabaseCaseDetailRepository: CaseDetailRepository = {
  async getByContentId(contentId: string) {
    const supabase = await createClient()

    const { data, error } = await supabase
      .from('case_detail')
      .select(
        `
        content_id,
        force,
        client
      `,
      )
      .eq('content_id', contentId)
      .maybeSingle()

    if (error) {
      throw createRepositoryError(error.message, error.code)
    }

    if (!data) {
      return null
    }

    return mapCaseDetail(data)
  },

  async upsert(input: UpsertCaseDetailInput) {
    const supabase = await createClient()

    const { data, error } = await supabase.rpc('upsert_case_detail', {
      p_content_id: input.contentId,

      p_force: input.force,

      p_client: input.client,
    })

    if (error) {
      throw createRepositoryError(error.message, error.code)
    }

    return data
  },
}
