import { createClient } from '@/lib/supabase/server'

import type { ContentTranslationRepository } from '@/modules/content/domain/contentTranslationRepository'

import type {
  ContentTranslation,
  UpsertContentTranslationInput,
} from '@/modules/content/domain/contentTranslationSchema'

import type { Locale } from '@/modules/shared/domain/locale'
import { createRepositoryError } from '@/lib/supabase/repositoryError'

type SupabaseTranslationRow = {
  content_id: string
  locale: Locale
  title: string
  seo_title: string | null
  seo_description: string | null
  summary: string | null
  highlight: string | null
  body: string | null
}

function mapTranslation(row: SupabaseTranslationRow): ContentTranslation {
  return {
    contentId: row.content_id,

    locale: row.locale,

    title: row.title,

    seoTitle: row.seo_title,

    seoDescription: row.seo_description,

    summary: row.summary,

    highlight: row.highlight,

    body: row.body,
  }
}

export const supabaseContentTranslationRepository: ContentTranslationRepository =
  {
    async listByContentId(contentId: string) {
      const supabase = await createClient()

      const { data, error } = await supabase
        .from('content_translation')
        .select(
          `
        content_id,
        locale,
        title,
        seo_title,
        seo_description,
        summary,
        highlight,
        body
      `,
        )
        .eq('content_id', contentId)

      if (error) {
        throw createRepositoryError(error.message, error.code)
      }

      return ((data ?? []) as SupabaseTranslationRow[]).map(mapTranslation)
    },

    async upsert(input: UpsertContentTranslationInput) {
      const supabase = await createClient()

      const { data, error } = await supabase.rpc('upsert_content_translation', {
        p_content_id: input.contentId,

        p_locale: input.locale,

        p_title: input.title,

        p_seo_title: input.seoTitle,

        p_seo_description: input.seoDescription,

        p_summary: input.summary,

        p_highlight: input.highlight,

        p_body: input.body,
      })

      if (error) {
        throw createRepositoryError(error.message, error.code)
      }

      return data
    },
  }
