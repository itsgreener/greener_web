import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'
import type { Database } from '@/lib/supabase/database'
import { env } from '@/lib/env'
import { hardenSessionCookie } from '@/lib/supabase/sessionCookies'

export async function createClient() {
  const cookieStore = await cookies()

  return createServerClient<Database>(
    env.NEXT_PUBLIC_SUPABASE_URL!,
    env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll()
        },

        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) => {
              cookieStore.set(name, value, hardenSessionCookie(options))
            })
          } catch {
            // El Proxy será responsable de refrescar
            // la sesión cuando sea necesario.
          }
        },
      },
    },
  )
}
