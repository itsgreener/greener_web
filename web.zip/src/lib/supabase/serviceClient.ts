import 'server-only'

import { createClient as createSupabaseClient } from '@supabase/supabase-js'
import type { Database } from '@/lib/supabase/database'
import { env } from '@/lib/env'

/**
 * Cliente de Supabase con la SECRET KEY (service role): salta RLS por
 * completo. Úsalo únicamente en código que se ejecuta en servidor y
 * solo para las tablas que arquitectónicamente no tienen política
 * pública — hoy, feed_session/feed_round (§8.5: "el cliente no puede
 * alterar cuotas ni seed", ver comentario de la migración
 * 20260806090700_rls_policies.sql), y `content`/`case_detail`/`episode`
 * exclusivamente desde `resolvePreviewContext.ts` (§15.3: preview con
 * token firmado) — ahí la RLS bloquea por completo cualquier lectura de
 * contenido no publicado, así que un token válido es la única forma de
 * ver un borrador sin sesión de admin.
 *
 * También lo usa el calentamiento de vídeos (fase 2, contrato §9) para
 * anotar con `mark_media_asset_warmed` desde `after()`, donde la sesión del
 * admin no está garantizada (la función admite el rol de servicio).
 *
 * Importadores permitidos (los fija `tests/unit/security/serviceClientImporters.test.ts`):
 * `content/container.ts` (preview), `feed/infrastructure/feedSessionRepository.ts`,
 * `media/infrastructure/supabaseWarmRepository.ts`,
 * `contact/infrastructure/contactSubmissionLog.ts`,
 * `audit/infrastructure/serviceAuditRecorder.ts`,
 * `packages/infrastructure/supabaseStorageSource.ts` (bucket privado) y
 * `packages/infrastructure/supabaseStagedUploadSweeper.ts` (limpieza semanal de
 * `_incoming/`, que corre sin sesión de admin).
 *
 * NUNCA importar este módulo desde un componente cliente ('use client')
 * ni exponer su resultado, directa o indirectamente, en una respuesta al
 * navegador. Para todo lo que sí tiene política pública de lectura
 * (content, pin, tag, feed_config...), usa un cliente normal con la
 * publishable key — no hace falta saltarse RLS para leer lo que ya es
 * público.
 */
export function createServiceClient() {
  return createSupabaseClient<Database>(
    env.NEXT_PUBLIC_SUPABASE_URL,
    env.SUPABASE_SECRET_KEY,
    {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    },
  )
}
