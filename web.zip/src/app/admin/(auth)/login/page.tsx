'use client'

import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import { Suspense, useState } from 'react'

import { AdminBrand } from '@/components/admin/AdminBrand'
import { AdminButton } from '@/components/admin/AdminButton'
import { AdminMessage } from '@/components/admin/AdminMessage'
import { createClient } from '@/lib/supabase/client'

import styles from './page.module.css'

// El callback y el proxy mandan aquí con `?error=…`. Sin esto la persona
// volvía al login sin saber por qué.
const URL_ERROR_MESSAGES: Record<string, string> = {
  unauthorized:
    'Esa cuenta no tiene acceso al panel. Usa una cuenta corporativa autorizada.',
  oauth: 'No se ha podido iniciar sesión con Google. Inténtalo de nuevo.',
}

function UrlErrorMessage() {
  const code = useSearchParams().get('error')
  const message = code ? URL_ERROR_MESSAGES[code] : undefined

  if (!message) return null

  return (
    <div className={styles.error}>
      <AdminMessage kind="error" role="alert">
        {message}
      </AdminMessage>
    </div>
  )
}

export default function AdminLoginPage() {
  const [loading, setLoading] = useState(false)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  const loginWithGoogle = async () => {
    setLoading(true)
    setErrorMessage(null)

    const supabase = createClient()

    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${window.location.origin}/auth/callback?next=/admin`,
      },
    })

    if (error) {
      console.error(error)

      setErrorMessage(
        'No se ha podido iniciar sesión con Google. Inténtalo de nuevo.',
      )

      setLoading(false)
    }
  }

  return (
    <main className={styles.page}>
      <section className={styles.card}>
        <div className={styles.brand}>
          <AdminBrand />
        </div>

        <div className={styles.content}>
          <div className={styles.heading}>
            <p className={styles.eyebrow}>Panel de administración</p>

            <h1 className={styles.title}>Bienvenido</h1>

            <p className={styles.lead}>
              Accede para gestionar contenidos, publicaciones, herramientas y
              recursos de Greener.
            </p>
          </div>

          <AdminButton
            type="button"
            className={styles.google}
            onClick={loginWithGoogle}
            disabled={loading}
          >
            <span className={styles.googleIcon} aria-hidden="true">
              {/* Los cuatro colores literales son los de la marca de Google: la única excepción a los tokens en todo el ABM. */}
              <svg
                viewBox="0 0 24 24"
                width="20"
                height="20"
                role="presentation"
              >
                <path
                  fill="#4285F4"
                  d="M21.6 12.23c0-.71-.06-1.4-.18-2.07H12v3.92h5.38a4.6 4.6 0 0 1-2 3.02v2.51h3.24c1.9-1.75 2.98-4.33 2.98-7.38Z"
                />
                <path
                  fill="#34A853"
                  d="M12 22c2.7 0 4.97-.9 6.62-2.39l-3.24-2.51c-.9.6-2.05.96-3.38.96-2.61 0-4.82-1.76-5.61-4.13H3.04v2.59A10 10 0 0 0 12 22Z"
                />
                <path
                  fill="#FBBC05"
                  d="M6.39 13.93A6 6 0 0 1 6.07 12c0-.67.12-1.32.32-1.93V7.48H3.04A10 10 0 0 0 2 12c0 1.62.39 3.15 1.04 4.52l3.35-2.59Z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.94c1.47 0 2.79.5 3.83 1.5l2.87-2.87C16.97 2.96 14.7 2 12 2a10 10 0 0 0-8.96 5.48l3.35 2.59C7.18 7.7 9.39 5.94 12 5.94Z"
                />
              </svg>
            </span>

            <span>
              {loading ? 'Conectando con Google…' : 'Continuar con Google'}
            </span>
          </AdminButton>

          <Suspense fallback={null}>
            <UrlErrorMessage />
          </Suspense>

          {errorMessage && (
            <div className={styles.error}>
              <AdminMessage kind="error" role="alert">
                {errorMessage}
              </AdminMessage>
            </div>
          )}

          <div className={styles.security}>
            <span className={styles.securityIcon} aria-hidden="true">
              ✓
            </span>

            <p className={styles.securityText}>
              Utiliza una cuenta corporativa autorizada para acceder al panel.
            </p>
          </div>
        </div>

        <footer className={styles.footer}>
          <Link href="/">← Volver a la web</Link>

          <span className={styles.footerBrand}>Greener Admin</span>
        </footer>
      </section>
    </main>
  )
}
